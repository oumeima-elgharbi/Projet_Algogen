--------------------------------
 ``problem_function`` module
--------------------------------


Classe Individus functions
--------------------------

.. autoclass:: problems.problem_function.problem_function.ProblemFunction
   :members:

Classe Problèmes functions
--------------------------

.. autoclass:: problems.problem_function.individual_function.IndividualFunction
   :members:

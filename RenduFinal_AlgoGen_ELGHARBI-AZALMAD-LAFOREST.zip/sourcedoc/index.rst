=====================
AP2 project : AlgoGen
=====================


.. toctree::
   :maxdepth: 1

   algogen
   problem_interface
   individual_interface
   problem_function
   problem_secret
   problem_maze
   problem_haunted
   journal

	






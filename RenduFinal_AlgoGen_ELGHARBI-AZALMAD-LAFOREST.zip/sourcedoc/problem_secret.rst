--------------------------------
 ``problem_secret`` module
--------------------------------


Classe Individus secret
------------------------

.. autoclass:: problems.problem_secret.problem_secret.ProblemSecret
   :members:

Classe Problèmes secret
------------------------

.. autoclass:: problems.problem_secret.individual_secret.IndividualSecret
   :members:

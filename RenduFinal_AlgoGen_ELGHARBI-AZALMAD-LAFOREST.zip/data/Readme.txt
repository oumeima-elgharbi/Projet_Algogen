** Projet AP2 : Algorithme génétique

Auteurs : Achraf Azalmad, Oumeima El Gharbi, Geoffrey Laforest.
L2 Maths, groupe 1

date : 20/11/2019

Nous avons réparti le travail entre nous,
Achraf fait le problème 1,
Oumeima fait le problème 2,
Geoffrey fait le problème 3.

date : 27/11/2019

Nous avons chacun avancé dans la programmation des classes individus et problèmes pour le problème qui nous est attribué.

Il reste la classe Algogen à finir et à optimiser aussi, nous ferons cela pour la semaine prochaine.

date : 10/12/2019 Rendu final

Nous avons fini les 4 problèmes et les fichiers rst, ainsi que le diaporama.

Mode d'emploi pour l'execution en ligne de commande : 

	main_function.py : nombre de générations / taille de la population / probabilité de mutation / taille du génome  / xmin / xmax

	main_secret.py : nombre de générations / taille de la population / probabilité de mutation
	
	main_maze.py :  nombre de générations / taille de la population / probabilité de mutation / Le numéro du labyrinthe (problème maze) ; si numéro = 1, alors on appelle maze1.txt
	Nous avons un problème au niveau du chemin quand on lance le programme à partir d'une console ubuntu, sur windows on peut lancer le programme et cela fonctionne.

	main_haunted.py :  nombre de générations / taille de la population / probabilité de mutation / hauteur / largeur / le nombre de monstres / N (itérations pour créer plusieurs haunted fields). 

